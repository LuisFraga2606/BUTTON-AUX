package com.example.hackathon;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {

    TextView LETRAS;

    private final int DURACION_SPLASH = 4000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);





        LETRAS = (TextView)findViewById(R.id.tvHACK);
        Animation efecto = AnimationUtils.loadAnimation(this, R.anim.nueva_transicion);

        LETRAS.setAnimation(efecto);


        new Handler().postDelayed(new Runnable() {
            public void run() {
                Intent intent = new Intent(MainActivity.this, MENU.class);
                startActivity(intent);
                finish();
            }

            ;
        }, DURACION_SPLASH);


    }
}
